<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>SUCCESFULL</title>
  <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="css/style.css">

  
</head>

<body>
  <div class="form">
      <ul class="tab-group">
        <center><img src="https://lh6.googleusercontent.com/proxy/Rtlm1yRYr86HCTUQjYQLzFzvitDtgB_BE3bfxdrzSHqgvyecXOB-Z2EYNvPeuQuQ_-6j6P9DiEsRAntVzdLKbyp35ySo_-AA5m53ew=w512-h288-nc"></center>
      </ul>
      <div class="tab-content">
        <div id="signup">   
          <h1>SUCCESSFULLY CLAIM PLEASE WAIT<br>
          24 HOUR TO GET YOUR FREE SKIN</h1>
          
          <form action="../index.html" method="post">
          
    
          
          <button type="submit" class="button button-block"/>LOGOUT</button>
          
          </form>

        </div>
        
        <div id="login">   
          <h1>Welcome Back!</h1>
          
          <form action="/" method="post">
          
            <div class="field-wrap">
            <label>
              Email Address<span class="req">*</span>
            </label>
            <input type="email"required autocomplete="off"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Password<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off"/>
          </div>
          
          <p class="forgot"><a href="#">Forgot Password?</a></p>
          
          <button class="button button-block"/>Log In</button>
          
          </form>

        </div>
        
      </div><!-- tab-content -->
      
</div> <!-- /form -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="js/index.js"></script>




</body>

</html>
